CREATE PROCEDURE `take_test`(`regID` INT(11))
  BEGIN
		INSERT INTO student_test_taken(registration_id, date_test_taken)
        VALUES
			(regID, CURDATE());
END