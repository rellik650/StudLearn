CREATE PROCEDURE `course_enrolment`(`regID` INT(11), `studID` INT(11), `courseID` INT(11))
  BEGIN
	INSERT INTO student_course_enrolment(registration_id, student_id, course_id, date_of_enrolment)
    VALUES(regID, studID, courseID, CURDATE());
END