CREATE PROCEDURE `finish_course`(`regID` INT(11))
  BEGIN
	UPDATE student_course_enrolment
    SET date_of_completion = CURDATE()
    WHERE registration_id = regID;
END