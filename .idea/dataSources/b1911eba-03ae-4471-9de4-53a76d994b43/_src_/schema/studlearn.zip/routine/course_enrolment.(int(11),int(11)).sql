CREATE PROCEDURE `course_enrolment`(`studID` INT(11), `courseID` INT(11))
  BEGIN
	INSERT INTO student_course_enrolment(student_id, course_id, date_of_enrolment)
    VALUES(studID, courseID, CURDATE());
END