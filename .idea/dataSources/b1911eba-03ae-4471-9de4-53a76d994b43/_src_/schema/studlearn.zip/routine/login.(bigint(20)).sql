CREATE PROCEDURE `login`(`user_id_in` BIGINT(20))
  BEGIN
	UPDATE users SET date_of_latest_logon = NOW()
    WHERE user_id_in = user_id;
END