CREATE PROCEDURE `update_grade`(`regID` INT(11), `grade` INT(11))
  BEGIN
	UPDATE student_test_taken
    SET test_reusult = grade
    WHERE registration_id = regID;
END